namespace Logic.Actions {
    interface IActionAffectable {
        
    }
}