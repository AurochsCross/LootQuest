namespace Models.Items {
    public enum ArmorType {
        none,
        helmet,
        body,
        legs
    };
}